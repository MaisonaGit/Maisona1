<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{carriercompare}prestashop>carriercompare_c65b3289df9c2c54a493dcd271d24df0'] = 'Estimation des livraisons';
$_MODULE['<{carriercompare}prestashop>carriercompare_369f88ec14d06a2166f5fcd4e7c919f1'] = 'Module permettant de faire une estimation des coûts de livraison avant d\'entrer dans le processus de commande';
$_MODULE['<{carriercompare}prestashop>carriercompare_1566d7b28dafe92a3beaef0c7be84288'] = 'identifiant d\'état non valable';
$_MODULE['<{carriercompare}prestashop>carriercompare_ff22c3e7b4cd12813e2033774d987e96'] = 'Choissisez un état';
$_MODULE['<{carriercompare}prestashop>carriercompare_fb9e838d470b2c27c2c128d127165f9e'] = 'Choississez un pays';
$_MODULE['<{carriercompare}prestashop>carriercompare_7346db5da590c9226acab07187d813c3'] = 'Veuillez utiliser un code postal valable en fonction du pays choisi';
$_MODULE['<{carriercompare}prestashop>carriercompare_3f63451bbacbb1c3303d99d0309fdfe9'] = 'Choississez un transporteur';
$_MODULE['<{carriercompare}prestashop>carriercompare_b3cdf90f7e9ade805f2adbe34975240f'] = 'Cet identifiant de transporteur n\'est pas disponible pour votre sélection';
$_MODULE['<{carriercompare}prestashop>carriercompare_f19b63c54e29865988908a07fd566480'] = 'Impossible de mettre à jour le panier';
$_MODULE['<{carriercompare}prestashop>carriercompare_2833e625c13a70c7b84ad98c97976c9d'] = 'Rechargement de la page et mise à jour du panier...';
$_MODULE['<{carriercompare}prestashop>carriercompare_b49f15ff6f8530a76ed954676abbc4d6'] = 'Vérification des états disponibles...';
$_MODULE['<{carriercompare}prestashop>carriercompare_ed22df3e47c667a95dd43e59f2f38522'] = 'Récupération des informations...';
$_MODULE['<{carriercompare}prestashop>carriercompare_e7a6ca4e744870d455a57b644f696457'] = 'Offert !';
$_MODULE['<{carriercompare}prestashop>carriercompare_533bf2149f935df1f934e5ee55f68d20'] = 'Estimez vos frais de livraison & taxes';
$_MODULE['<{carriercompare}prestashop>carriercompare_59716c97497eb9694541f7c3d37b1a4d'] = 'Pays';
$_MODULE['<{carriercompare}prestashop>carriercompare_46a2a41cc6e552044816a2d04634545d'] = 'Etat';
$_MODULE['<{carriercompare}prestashop>carriercompare_5e178542b85fb18ca3c459e9a95f4f2e'] = 'Code postal';
$_MODULE['<{carriercompare}prestashop>carriercompare_9207f4078f515ecc8256bae33fa1f497'] = 'Nécessaires pour certains transporteurs';
$_MODULE['<{carriercompare}prestashop>carriercompare_914419aa32f04011357d3b604a86d7eb'] = 'Transporteur';
$_MODULE['<{carriercompare}prestashop>carriercompare_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Information';
$_MODULE['<{carriercompare}prestashop>carriercompare_3601146c4e948c32b6424d2c0a7f0118'] = 'Prix';
$_MODULE['<{carriercompare}prestashop>carriercompare_568ee69520d3299f2f0ea64d501b6f50'] = 'Aucun  transporteur n\'est disponible pour cette sélection';
$_MODULE['<{carriercompare}prestashop>carriercompare_1de0f9fcbe30b056483fe964aed55adc'] = 'Mettre à jour le panier';
$_MODULE['<{carriercompare}prestashop>carriercompare_653e78154f5596fc293bf9db65110bbd'] = 'Mise a jour de la liste de transporteurs';
$_MODULE['<{carriercompare}prestashop>configuration_a2d3779b2b18f09740a46050388e08f0'] = 'Une erreur est survenue lors de la validation du formulaire';
$_MODULE['<{carriercompare}prestashop>configuration_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise a jour';
$_MODULE['<{carriercompare}prestashop>configuration_99e09df7d3344d2d04153f297163affa'] = 'Ce module est disponible uniquement sur les processus de commande standard, car sur le One Page Checkout la liste des transporteurs est déjà disponible.';
$_MODULE['<{carriercompare}prestashop>configuration_6408d076fa6417e7bc8ddc3cdf9a0644'] = 'Configuration globale';
$_MODULE['<{carriercompare}prestashop>configuration_4c1f76824b0d7333652d5f64a3e07ef5'] = 'N\'importe quand';
$_MODULE['<{carriercompare}prestashop>configuration_31efb362f3723b55bfa28f3551a672f7'] = 'Quand toutes les informations sont complètes';
$_MODULE['<{carriercompare}prestashop>configuration_9c7cc22fb61d22cf2560f172ea85ab7b'] = 'Défini la manière dont l\'information présentée à l\'utilisateur doit être rafraîchie';
$_MODULE['<{carriercompare}prestashop>configuration_a4d3b161ce1309df1c4e25df28694b7b'] = 'Soumettre';
