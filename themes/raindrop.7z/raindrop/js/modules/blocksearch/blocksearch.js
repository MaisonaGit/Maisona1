$(document).ready(function(){
//    var width = $(window).width();
//    var search = $('.search_query');
//    
//    // test case for landscape and portrait smartphone
//    if(width >= '767') {
//        search.focusin(function(){
//            search.animate({
//               width: '170px'  
//            }, "slow" );
//        });
//
//        search.focusout(function(){
//            search.animate({
//               width: '140px'  
//            }, "slow" );
//        });
//    }
});