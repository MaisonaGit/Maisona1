<?php

global $_LANG;
$_LANG = array();